# Herd Immunity Project

This is a project for the HPC-05 Programming Lab "Disease Simulation".
